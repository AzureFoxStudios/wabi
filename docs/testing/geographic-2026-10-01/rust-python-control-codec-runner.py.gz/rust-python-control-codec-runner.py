import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import uuid

REPO = Path('/home/ironin/wabi')
BASE = REPO/'docs/testing/geographic-2026-10-01'
accepted = json.loads((BASE/'encrypted-rpc-contracts.json').read_text())
artifact = next(a for a in accepted['artifacts'] if 'encrypted_tcp_contract-' in a['path'])
spec = importlib.util.spec_from_file_location('real_rpc_controller', REPO/'scripts/geographic-acceptance/rpc-probe-controller.py')
ctl = importlib.util.module_from_spec(spec);sys.modules[spec.name] = ctl;spec.loader.exec_module(ctl)
guard = ctl.guard
stage = Path(tempfile.mkdtemp(prefix='wgc-', dir='/tmp'));stage.chmod(0o700)
original = stage.stat()
owner = uuid.uuid4().hex + uuid.uuid4().hex
roots = {};sessions = {};leases = {};clients = {};threads = {};readers = {};supervision = {};errors = {}
result = {'schemaVersion':1,'scope':'Actual Rust/Python disposable local control interface and guarded restart',
          'artifact':artifact,'canonicalWriterPermitted':False,'physicalThreeSiteTested':False,'automaticWabiRecoveryTested':False}

def private_json(path,value):
    body = ctl.encoded(value)
    fd = os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as out:out.write(body);out.flush();os.fsync(out.fileno())
    return hashlib.sha256(body).hexdigest()

def supervise(node):
    try:supervision[node] = sessions[node].run(readers[node],lifetime=75,idle=12,allow_restart=True)
    except BaseException as error:errors[node] = type(error).__name__

def pulse():
    for lease in leases.values():lease.keepalive()

def receipts(intent, seconds=15):
    deadline = time.monotonic()+seconds
    while time.monotonic()<deadline:
        pulse()
        try:
            observations=[clients[n].request('receipt',intent=intent,timeout=1) for n in (1,2,3)]
            return observations,ctl.convergence(observations,intent)
        except ctl.Refused:time.sleep(.05)
    raise RuntimeError('receipt_convergence_deadline')

try:
    src = REPO/artifact['path']
    assert src.stat().st_size==artifact['bytes'] and hashlib.sha256(src.read_bytes()).hexdigest()==artifact['sha256']
    assert artifact['bytes']<256*1024*1024
    public={}
    for node in (1,2,3):
        root=stage/str(node);root.mkdir(mode=0o700);roots[node]=root
        dest=root/'probe.bin';shutil.copyfile(src,dest);dest.chmod(0o700)
        assert hashlib.sha256(dest.read_bytes()).hexdigest()==artifact['sha256']
        private_json(root/'fixture.json',{'schemaVersion':1,'nodeId':node,'owner':owner})
        child=subprocess.Popen([str(dest),'--exact','processes::separate_process_identity_bootstrap',
                                '--ignored','--nocapture','--test-threads=1'],stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
                                env={'WABI_RPC_FIXTURE_ROOT':str(root),'WABI_RPC_FIXTURE_OWNER':owner})
        try:output,_=child.communicate(timeout=5)
        finally:
            if child.poll() is None:child.kill();child.wait(timeout=5)
            if child.stdout:child.stdout.close()
        assert child.returncode==0 and len(output)<=4096
        tagged=[line.split(b'WABI_RPC_NODE_PUBLIC_V1 ',1)[1] for line in output.splitlines() if b'WABI_RPC_NODE_PUBLIC_V1 ' in line]
        assert len(tagged)==1
        value=json.loads(tagged[0]);assert value['nodeId']==node and guard.hex64(value['publicKey'])
        public[node]=value['publicKey']
    assert len(set(public.values()))==3
    reserved=[];addresses={}
    for node in (1,2,3):
        endpoint=socket.socket(socket.AF_INET,socket.SOCK_STREAM);endpoint.bind(('127.0.0.1',0))
        reserved.append(endpoint);addresses[node]='127.0.0.1:'+str(endpoint.getsockname()[1])
    community=hashlib.sha256(uuid.uuid4().bytes).hexdigest()
    peers={str(n):{'protocol':1,'communityId':community,'siteId':'local-codec-'+str(n),
                   'publicKey':public[n],'rpcAddress':addresses[n]} for n in (1,2,3)}
    configs={}
    for node,root in roots.items():
        (root/'fixture.json').unlink()
        configs[node]=private_json(root/'fixture.json',{'binding':{'communityId':community,'partitionId':'room:fixture','nodeId':node},
            'peers':peers,'bindAddress':addresses[node],'owner':owner,
            'raftTiming':{'heartbeatMs':500,'electionMinMs':2500,'electionMaxMs':5000,'snapshotTimeoutMs':10000}})
        sessions[node]=guard.Session(str(root),owner,artifact['sha256'],node,claim=True)
        readers[node],writer=os.pipe();os.set_blocking(writer,False)
        leases[node]=ctl.Lease(writer);os.close(writer)
        clients[node]=ctl.Client(str(root),owner,artifact['sha256'],configs[node],node,lease=leases[node])
    for endpoint in reserved:endpoint.close()
    for node in (1,2,3):
        threads[node]=threading.Thread(target=supervise,args=(node,));threads[node].start()
    deadline=time.monotonic()+10
    initial={}
    while len(initial)<3 and time.monotonic()<deadline:
        pulse()
        for node in (1,2,3):
            if node in initial:continue
            try:initial[node]=clients[node].request('status',timeout=1).value
            except ctl.Refused:pass
        time.sleep(.02)
    assert len(initial)==3 and all(v['canonicalWriterPermitted'] is False for v in initial.values())
    initialized=clients[1].request('initialize',timeout=3).value
    assert initialized['result']=='initialized'
    deadline=time.monotonic()+15;leader=None
    while time.monotonic()<deadline and leader is None:
        pulse()
        for node in (1,2,3):
            if clients[node].request('status',timeout=1).value['isLeader']:leader=node;break
        if leader is None:time.sleep(.05)
    assert leader is not None
    intent=ctl.Intent.from_command({'operationId':'0'*31+'1','partitionId':'room:fixture','expectedEpoch':0,
                                    'proposedWriter':1,'checkpointInventorySha256':'ab'*32})
    proposed=clients[leader].request('propose',intent=intent,timeout=3).value
    assert proposed['result']=='committed' and proposed['control']['outcome']=='accepted'
    before,converged=receipts(intent)
    changed=ctl.Intent.from_command(dict(intent.command,proposedWriter=2))
    changed_refused=False
    try:clients[leader].request('propose',intent=changed,timeout=3)
    except (ctl.Refused,ctl.Indeterminate):changed_refused=True
    assert changed_refused
    receipts(intent)
    victim=next(n for n in (1,2,3) if n!=leader)
    lock_before=(roots[victim]/'.lock').stat();key_before=(roots[victim]/'recovery.key').stat()
    dead=sessions[victim].child;dead.kill();dead.wait(timeout=5)
    leases[victim].restart()
    after,_=receipts(intent)
    lock_after=(roots[victim]/'.lock').stat();key_after=(roots[victim]/'recovery.key').stat()
    assert (lock_before.st_dev,lock_before.st_ino)==(lock_after.st_dev,lock_after.st_ino)
    assert (key_before.st_dev,key_before.st_ino)==(key_after.st_dev,key_after.st_ino)
    assert [ctl.accepted_receipt(o,intent) for o in before]==[ctl.accepted_receipt(o,intent) for o in after]
    result.update({'status':'PASS','realRustRepliesValidatedByPython':True,'realThreeVoterReceiptConvergence':converged,
        'sameIdChangedContentsCannotBorrowOriginalReceipt':True,'originalReceiptAfterActualWorkerSigkillAndRestart':True,
        'originalStoreLockAndPrivateKeyInodesPreserved':True,'rustPythonOriginalCommandSha256':intent.sha256,
        'independentPrivateNodeKeysCreatedInOwnedLocalFixtures':3,'nodeLabels':[1,2,3],'configSha256':{str(k):v for k,v in configs.items()}})
except BaseException as error:
    result.update({'status':'FAIL','errorType':type(error).__name__})
finally:
    for lease in leases.values():
        try:lease.stop()
        except (OSError,ctl.Refused):pass
        lease.close()
    for thread in threads.values():thread.join(timeout=18)
    alive=[n for n,t in threads.items() if t.is_alive()]
    for node,session in sessions.items():
        if node not in alive:session.close()
    for node,reader in readers.items():
        if node not in alive:os.close(reader)
    leftovers=[n for n,p in roots.items() if p.exists()]
    if not alive and not leftovers:
        assert (stage.stat().st_dev,stage.stat().st_ino)==(original.st_dev,original.st_ino)
        stage.rmdir()
    result['cleanup']={'supervisorReceipts':{str(n):v for n,v in supervision.items()},'supervisorErrorTypes':errors,
        'ownedThreadsRemaining':alive,'ownedNodeRootsRemaining':leftovers,'ownedParentStageRemoved':not stage.exists()}
    if alive or leftovers or errors:result['status']='FAIL'
    result['recordedAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['sourceDigests']={str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [
        REPO/'scripts/geographic-acceptance/rpc-probe-supervisor.py',REPO/'scripts/geographic-acceptance/rpc-probe-controller.py']}
    raw=Path(__file__).read_bytes();result['runnerSourceSha256']=hashlib.sha256(raw).hexdigest()
    with (BASE/'rust-python-control-codec-contract.json').open('x') as out:json.dump(result,out,indent=2);out.write('\n')
    with (BASE/'rust-python-control-codec-runner.py.gz').open('xb') as out:out.write(gzip.compress(raw,mtime=0))
    assert gzip.decompress((BASE/'rust-python-control-codec-runner.py.gz').read_bytes())==raw
    print(json.dumps({'status':result['status'],'errorType':result.get('errorType'),'cleanup':result['cleanup']}),flush=True)
sys.exit(0 if result['status']=='PASS' else 1)
