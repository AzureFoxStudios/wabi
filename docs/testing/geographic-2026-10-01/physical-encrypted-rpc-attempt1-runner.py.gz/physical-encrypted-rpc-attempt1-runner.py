import base64,datetime,gzip,hashlib,importlib.util,json,os,selectors,shlex,subprocess,sys,time,uuid
from pathlib import Path
REPO=Path('/home/ironin/wabi');BASE=REPO/'docs/testing/geographic-2026-10-01'
spec=importlib.util.spec_from_file_location('physical_control',REPO/'scripts/geographic-acceptance/rpc-probe-controller.py')
ctl=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ctl;spec.loader.exec_module(ctl)
SOURCE_NAMES=('rpc-probe-controller.py','rpc-probe-supervisor.py')
helpers={n:{'body':(REPO/'scripts/geographic-acceptance'/n).read_text(),'sha256':hashlib.sha256((REPO/'scripts/geographic-acceptance'/n).read_bytes()).hexdigest()} for n in SOURCE_NAMES}
accepted=json.loads((BASE/'encrypted-rpc-contracts.json').read_text())
artifact=next(a for a in accepted['artifacts'] if 'encrypted_tcp_contract-' in a['path'])
raw=(REPO/artifact['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==artifact['sha256']
packed=gzip.compress(raw,compresslevel=3,mtime=0);del raw
encoded_artifact=base64.b64encode(packed).decode();del packed
owner=uuid.uuid4().hex+uuid.uuid4().hex
REMOTE=r'''
import base64,gzip,hashlib,importlib.util,io,json,os,platform,selectors,shutil,signal,socket,subprocess,sys,tempfile,threading,time
from pathlib import Path
payload=json.loads(sys.stdin.buffer.readline(40*1024*1024+1));assert platform.node()==payload['host']
assert payload['node'] in (1,2,3) and len(payload['owner'])==64
assert payload['artifact']['bytes']<256*1024*1024
stage=Path(tempfile.mkdtemp(prefix='wgp-',dir='/tmp'));stage.chmod(0o700);original=stage.stat()
root=stage/'n';root.mkdir(mode=0o700);session=None;lease=None;thread=None;reader=None;reserved=None
supervision={};interrupted=False;configured=False;before_kill=None
def interrupt(*_):
 global interrupted
 interrupted=True
for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(sig,interrupt)
def emit(value):print(json.dumps(value,separators=(',',':')),flush=True)
def private_json(path,value):
 body=json.dumps(value,separators=(',',':'),ensure_ascii=True).encode()
 assert len(body)<=16384
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as out:out.write(body);out.flush();os.fsync(out.fileno())
 return hashlib.sha256(body).hexdigest()
def supervise():
 try:supervision.update(session.run(reader,lifetime=110,idle=12,allow_restart=True))
 except BaseException as error:supervision.update({'result':'FAIL','errorType':type(error).__name__})
def inode(name):
 info=(root/name).stat();return [info.st_dev,info.st_ino]
try:
 for name,record in payload['helpers'].items():
  assert name in ('rpc-probe-controller.py','rpc-probe-supervisor.py')
  data=record['body'].encode();assert hashlib.sha256(data).hexdigest()==record['sha256']
  with (stage/name).open('xb') as out:out.write(data)
  (stage/name).chmod(0o600)
 source=importlib.util.spec_from_file_location('agent_control',stage/'rpc-probe-controller.py')
 ctl=importlib.util.module_from_spec(source);sys.modules[source.name]=ctl;source.loader.exec_module(ctl);guard=ctl.guard
 compressed=base64.b64decode(payload.pop('artifactBase64'),validate=True)
 with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:binary=stream.read(payload['artifact']['bytes']+1)
 assert len(binary)==payload['artifact']['bytes'] and hashlib.sha256(binary).hexdigest()==payload['artifact']['sha256']
 executable=root/'probe.bin'
 with executable.open('xb') as out:out.write(binary);out.flush();os.fsync(out.fileno())
 executable.chmod(0o700);del binary,compressed
 private_json(root/'fixture.json',{'schemaVersion':1,'nodeId':payload['node'],'owner':payload['owner']})
 child=subprocess.Popen([str(executable),'--exact','processes::separate_process_identity_bootstrap','--ignored','--nocapture','--test-threads=1'],
  stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
  env={'WABI_RPC_FIXTURE_ROOT':str(root),'WABI_RPC_FIXTURE_OWNER':payload['owner']})
 try:output,_=child.communicate(timeout=10)
 finally:
  if child.poll() is None:child.kill();child.wait(timeout=5)
  if child.stdout:child.stdout.close()
 assert child.returncode==0 and len(output)<=4096
 tagged=[line.split(b'WABI_RPC_NODE_PUBLIC_V1 ',1)[1] for line in output.splitlines() if b'WABI_RPC_NODE_PUBLIC_V1 ' in line]
 assert len(tagged)==1
 public=json.loads(tagged[0]);assert public['nodeId']==payload['node'] and guard.hex64(public['publicKey'])
 reserved=socket.socket(socket.AF_INET,socket.SOCK_STREAM);reserved.bind((payload['ip'],0))
 address=payload['ip']+':'+str(reserved.getsockname()[1])
 emit({'event':'ready','node':payload['node'],'host':platform.node(),'python':platform.python_version(),'publicKey':public['publicKey'],
       'address':address,'artifactSha256':payload['artifact']['sha256'],'artifactBytes':payload['artifact']['bytes']})
 selector=selectors.DefaultSelector();selector.register(sys.stdin.buffer,selectors.EVENT_READ)
 deadline=time.monotonic()+150;commands=0
 while not interrupted and time.monotonic()<deadline and commands<128:
  if lease is not None:lease.keepalive()
  if not selector.select(.1):continue
  line=sys.stdin.buffer.readline(4097)
  if not line:break
  assert len(line)<=4096
  request=ctl.decode(line.strip());commands+=1
  action=request['action']
  try:
   if action=='configure':
    assert not configured
    config=request['config']
    assert config['binding']['nodeId']==payload['node'] and config['owner']==payload['owner']
    assert config['peers'][str(payload['node'])]['publicKey']==public['publicKey'] and config['bindAddress']==address
    (root/'fixture.json').unlink();config_sha=private_json(root/'fixture.json',config)
    session=guard.Session(str(root),payload['owner'],payload['artifact']['sha256'],payload['node'],claim=True)
    reader,writer=os.pipe();os.set_blocking(writer,False);lease=ctl.Lease(writer);os.close(writer)
    client=ctl.Client(str(root),payload['owner'],payload['artifact']['sha256'],config_sha,payload['node'],lease=lease)
    reserved.close();reserved=None
    thread=threading.Thread(target=supervise);thread.start();configured=True
    response={'configSha256':config_sha}
   elif action=='control':
    assert configured
    intent=ctl.Intent.from_command(request['command']) if 'command' in request else None
    observation=client.request(request['controlAction'],intent=intent,timeout=request.get('timeout',5))
    response={'request':ctl.decode(observation.request),'reply':observation.value}
   elif action=='kill':
    assert configured and session.child is not None and session.child.poll() is None
    before_kill={'lock':inode('.lock'),'key':inode('recovery.key')}
    child=session.child;child.kill();child.wait(timeout=5)
    response={'knownOwnedChildKilledAndReaped':True}
   elif action=='restart':
    assert configured and before_kill is not None
    lease.restart();response={'restartFrameSent':True}
   elif action=='restart_identity':
    assert configured and before_kill is not None
    response={'originalStoreLockAndPrivateKeyInodesPreserved':before_kill=={'lock':inode('.lock'),'key':inode('recovery.key')}}
   elif action=='finish':break
   else:raise ValueError('unsupported_action')
   emit({'event':'reply','status':'ok','result':response})
  except ctl.Indeterminate:emit({'event':'reply','status':'indeterminate','originalOperationReceiptRequired':True})
  except (ctl.Refused,OSError,ValueError,KeyError,AssertionError):emit({'event':'reply','status':'refused'})
 selector.close()
except BaseException as error:
 try:emit({'event':'setup_error','errorType':type(error).__name__})
 except BrokenPipeError:pass
finally:
 if reserved is not None:reserved.close()
 if lease is not None:
  try:lease.stop()
  except (OSError,ctl.Refused):pass
  lease.close()
 if thread is not None:thread.join(timeout=18)
 alive=thread is not None and thread.is_alive()
 if session is not None and not alive:session.close()
 if reader is not None and not alive:os.close(reader)
 # Pre-start refusal has no store/worker; only this newly owned private stage.
 if session is None and root.exists():shutil.rmtree(root)
 node_removed=not root.exists()
 if not alive and node_removed:
  assert (stage.stat().st_dev,stage.stat().st_ino)==(original.st_dev,original.st_ino)
  shutil.rmtree(stage)
 cleanup={'event':'cleanup','node':payload['node'],'ownedThreadStopped':not alive,'ownedNodeRootRemoved':node_removed,
          'ownedParentStageRemoved':not stage.exists(),'supervisor':supervision}
 try:emit(cleanup)
 except BrokenPipeError:pass
'''

owned_agents=[]
class Agent:
 def __init__(self,node,site,host,ip,target):
  self.node,self.site=node,site;self.buffer=b'';self.events=[]
  self.child=self.stderr=self.selector=None;self.finished=False
  owned_agents.append(self)
  self.stderr_path=Path('/tmp/wabi-geo-physical-rpc-20261001-b418e6-'+str(node)+'.stderr')
  self.stderr=self.stderr_path.open('xb')
  command=[sys.executable,'-B','-c',REMOTE] if target is None else ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',target,'python3 -B -c '+shlex.quote(REMOTE)]
  self.child=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr)
  os.set_blocking(self.child.stdin.fileno(),False)
  os.set_blocking(self.child.stdout.fileno(),False)
  self.selector=selectors.DefaultSelector();self.selector.register(self.child.stdout,selectors.EVENT_READ)
  payload={'node':node,'site':site,'host':host,'ip':ip,'owner':owner,'artifact':artifact,'artifactBase64':encoded_artifact,'helpers':helpers}
  self.write(json.dumps(payload,separators=(',',':')).encode()+b'\n',45)
  self.ready=self.read(45);assert self.ready['event']=='ready' and self.ready['node']==node and self.ready['host']==host
 def write(self,body,seconds):
  end=time.monotonic()+seconds;offset=0
  with selectors.DefaultSelector() as writable:
   writable.register(self.child.stdin,selectors.EVENT_WRITE)
   while offset<len(body):
    if self.child.poll() is not None:raise RuntimeError('agent_exited_during_bounded_write')
    remaining=end-time.monotonic()
    if remaining<=0:raise RuntimeError('agent_write_deadline')
    if not writable.select(min(.25,remaining)):continue
    try:offset+=os.write(self.child.stdin.fileno(),body[offset:offset+65536])
    except BlockingIOError:continue
 def read(self,seconds):
  end=time.monotonic()+seconds
  while time.monotonic()<end:
   if b'\n' in self.buffer:
    line,self.buffer=self.buffer.split(b'\n',1);value=json.loads(line);self.events.append(value);return value
   if self.selector.select(min(.25,max(0,end-time.monotonic()))):
    part=os.read(self.child.stdout.fileno(),8192)
    if not part:raise RuntimeError('agent_closed_before_receipt')
    self.buffer+=part
    assert len(self.buffer)<65536
  raise RuntimeError('agent_reply_deadline')
 def call(self,action,**fields):
  body=ctl.encoded(dict(action=action,**fields));assert len(body)<=4096
  self.write(body+b'\n',5)
  value=self.read(12);assert value['event']=='reply'
  return value
 def control(self,action,intent=None,timeout=5):
  fields={'controlAction':action,'timeout':timeout}
  if intent is not None:fields['command']=intent.command
  return self.call('control',**fields)
 def finish(self):
  assert not self.finished;self.finished=True
  value={'node':self.node,'cleanupConfirmed':False}
  if self.child is None:
   if self.stderr is not None:self.stderr.close()
   return value
  if self.child.poll() is None:
   try:self.write(b'{"action":"finish"}\n',2)
   except (BrokenPipeError,OSError,RuntimeError):pass
  if self.child.stdin:self.child.stdin.close()
  try:
   end=time.monotonic()+24
   while time.monotonic()<end:
    received=self.read(max(.1,end-time.monotonic()))
    if received.get('event')=='cleanup':value=received;break
  except (OSError,RuntimeError,AssertionError,json.JSONDecodeError) as error:
   value['cleanupReadErrorType']=type(error).__name__
  finally:
   try:value['processExitCode']=self.child.wait(timeout=10)
   except subprocess.TimeoutExpired:
    # This is our known local Python/SSH child, never an arbitrary remote PID.
    self.child.terminate()
    try:value['processExitCode']=self.child.wait(timeout=20)
    except subprocess.TimeoutExpired:
     self.child.kill();value['processExitCode']=self.child.wait(timeout=5)
    value['localTransportTerminationRequired']=True
   if self.selector is not None:self.selector.close()
   if self.child.stdout:self.child.stdout.close()
   if self.stderr is not None:self.stderr.close()
  value['knownLocalTransportReaped']=True
  return value

agents={};outcomes=[];intents=[];cleanup=[]
def observation(node,answer):
 assert answer['status']=='ok'
 value=answer['result'];ctl.validate_reply(value['reply'],node,(1,2,3))
 return ctl.Observation(ctl.encoded(value['request']),ctl.encoded(value['reply']))
def leader(ids,seconds=25):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  for node in ids:
   answer=agents[node].control('status',timeout=2)
   if answer['status']=='ok' and observation(node,answer).value['isLeader']:return node
  time.sleep(.1)
 raise RuntimeError('physical_leader_deadline')
def receipt_set(intent,ids,seconds=18):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  try:
   values=[observation(n,agents[n].control('receipt',intent,timeout=2)) for n in ids]
   controls=[ctl.accepted_receipt(v,intent) for v in values]
   assert all(v==controls[0] for v in controls)
   if len(ids)==3:ctl.convergence(values,intent)
   return values
  except (AssertionError,ctl.Refused):time.sleep(.1)
 raise RuntimeError('physical_exact_receipt_deadline')
def submit(ids,epoch):
 node=leader(ids)
 intent=ctl.Intent.from_command({'operationId':format(epoch+1,'032x'),'partitionId':'room:fixture','expectedEpoch':epoch,
    'proposedWriter':node,'checkpointInventorySha256':'ab'*32})
 started=time.monotonic();answer=agents[node].control('propose',intent,timeout=5)
 assert answer['status'] in ('ok','indeterminate')
 values=receipt_set(intent,ids)
 intents.append(intent)
 outcomes.append({'operation':epoch+1,'acknowledgingNode':node,'availableVoters':list(ids),'originalCommandSha256':intent.sha256,
   'exactReceipt':ctl.accepted_receipt(values[0],intent),'endToEndSeconds':round(time.monotonic()-started,3),'proposalReply':answer['status']})
 return intent

result={'schemaVersion':1,'scope':'Disposable three-physical-host encrypted recovery metadata coordination over private Tailscale IPs',
 'artifact':artifact,'artifactCompressedTransferBytesPerRemote':23599998,'physicalSitesIndependentlyCertified':False,
 'placementEvidence':'Earlier three-exit observation and operator site report; no public-address check repeated',
 'canonicalWriterPermitted':False,'automaticWabiRecoveryTested':False,'wabiAuthorityLaunched':False,'publicRouterOrFirewallChanges':0}
try:
 for row in [(1,'dotRonin','dotRonin','100.80.172.12',None),(2,'Ronin','bazzite','100.87.255.66','Ronin@100.87.255.66'),
             (3,'Iyoku','192.168.1.11','100.104.166.42','Iyoku@100.104.166.42')]:
  result['phase']='node_setup_'+str(row[0])
  agents[row[0]]=Agent(*row)
 assert len({a.ready['publicKey'] for a in agents.values()})==3
 community=hashlib.sha256(uuid.uuid4().bytes).hexdigest()
 peers={str(n):{'protocol':1,'communityId':community,'siteId':a.site,'publicKey':a.ready['publicKey'],'rpcAddress':a.ready['address']} for n,a in agents.items()}
 for n,a in agents.items():
  result['phase']='node_configure_'+str(n)
  config={'binding':{'communityId':community,'partitionId':'room:fixture','nodeId':n},'peers':peers,'bindAddress':a.ready['address'],
    'owner':owner,'raftTiming':{'heartbeatMs':500,'electionMinMs':2500,'electionMaxMs':5000,'snapshotTimeoutMs':10000}}
  assert a.call('configure',config=config)['status']=='ok'
 end=time.monotonic()+12
 for n,a in agents.items():
  while time.monotonic()<end:
   answer=a.control('status',timeout=1)
   if answer['status']=='ok':observation(n,answer);break
  else:raise RuntimeError('physical_worker_startup_deadline')
 assert agents[1].control('initialize',timeout=5)['status']=='ok'
 result['phase']='initial_majority_write'
 submit((1,2,3),0)
 failure_cases=[]
 for lost in (1,2,3):
  result['phase']='failure_and_return_'+str(lost)
  assert agents[lost].call('kill')['result']['knownOwnedChildKilledAndReaped']
  live=tuple(n for n in (1,2,3) if n!=lost)
  intent=submit(live,len(intents))
  assert agents[lost].call('restart')['status']=='ok'
  receipt_set(intent,(1,2,3))
  assert agents[lost].call('restart_identity')['result']['originalStoreLockAndPrivateKeyInodesPreserved']
  for original in intents:receipt_set(original,(1,2,3))
  failure_cases.append({'lostNode':lost,'majorityAcknowledged':True,'returnedNodeExactReceipts':True,'originalKeyAndStoreLockInodesPreserved':True})
 result.update({'status':'PASS','nodes':[{'node':n,'site':a.site,'host':a.ready['host'],'python':a.ready['python'],'artifactSha256':a.ready['artifactSha256']} for n,a in agents.items()],
  'threeIndependentDisposableNodeKeys':True,'initialAllThreeExactReceiptConvergence':True,'eachNodeKillMajorityWriteRestartCatchup':failure_cases,
  'operations':outcomes,'allOriginalReceiptsReadBackOnAllThree':True,'noiseRaftPhysicalControlTested':True,
  'physicalMinorityPartitionTested':False,'physicalSnapshotAfterPurgeTested':False})
except BaseException as error:result.update({'status':'FAIL','errorType':type(error).__name__,'completedOperations':outcomes})
finally:
 for a in owned_agents:
  try:cleanup.append(a.finish())
  except BaseException as error:cleanup.append({'node':a.node,'errorType':type(error).__name__,'cleanupConfirmed':False})
 result['cleanup']=cleanup
 if len(cleanup)!=3 or any(not c.get('ownedNodeRootRemoved') or not c.get('ownedParentStageRemoved') or not c.get('ownedThreadStopped') or c.get('processExitCode')!=0 for c in cleanup):result['status']='FAIL'
 result['recordedAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 result['helperSourceDigests']={n:v['sha256'] for n,v in helpers.items()}
 source=Path(__file__).read_bytes();result['runnerSourceSha256']=hashlib.sha256(source).hexdigest()
 with (BASE/'physical-encrypted-rpc-contracts.json').open('x') as out:json.dump(result,out,indent=2);out.write('\n')
 with (BASE/'physical-encrypted-rpc-runner.py.gz').open('xb') as out:out.write(gzip.compress(source,mtime=0))
 assert gzip.decompress((BASE/'physical-encrypted-rpc-runner.py.gz').read_bytes())==source
 print(json.dumps({'status':result['status'],'errorType':result.get('errorType'),'operations':len(outcomes),'cleanup':cleanup}),flush=True)
sys.exit(0 if result['status']=='PASS' else 1)
