import datetime,gzip,hashlib,json,os,selectors,shlex,subprocess,sys,time,uuid
from pathlib import Path
B=Path('/home/ironin/wabi/docs/testing/geographic-2026-10-01')
REMOTE=r'''
import json,platform,selectors,signal,socket,sys,threading,time
p=json.loads(sys.stdin.buffer.readline(1025));assert platform.node()==p['host']
assert len(p['challenge'])==64
stop=threading.Event()
for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(sig,lambda *_:stop.set())
listener=socket.socket();listener.bind((p['ip'],3000 if p['host']=='192.168.1.11' else 0));listener.listen(4);listener.settimeout(.2)
def serve():
 calls=0
 while not stop.is_set() and calls<32:
  try:s,_=listener.accept()
  except (socket.timeout,OSError):continue
  calls+=1
  with s:
   try:
    s.settimeout(2);data=s.recv(65)
    if data==p['challenge'].encode():s.sendall(data)
   except OSError:pass
t=threading.Thread(target=serve);t.start()
def emit(v):print(json.dumps(v),flush=True)
emit({'event':'ready','host':platform.node(),'address':listener.getsockname()})
selector=selectors.DefaultSelector();selector.register(sys.stdin.buffer,selectors.EVENT_READ)
deadline=time.monotonic()+60
try:
 while not stop.is_set() and time.monotonic()<deadline:
  if not selector.select(.2):continue
  line=sys.stdin.buffer.readline(4097)
  if not line:break
  assert len(line)<=4096
  request=json.loads(line)
  if request['action']=='finish':break
  assert request['action']=='probe' and len(request['targets'])==2
  results=[]
  for target in request['targets']:
   started=time.monotonic()
   try:
    with socket.create_connection(target['address'],timeout=2) as s:
     s.sendall(p['challenge'].encode());data=b''
     while len(data)<64:
      chunk=s.recv(64-len(data))
      if not chunk:break
      data+=chunk
     assert data==p['challenge'].encode()
    result={'target':target['node'],'status':'PASS'}
   except (OSError,AssertionError) as error:result={'target':target['node'],'status':'FAIL','errorType':type(error).__name__,'errno':getattr(error,'errno',None)}
   result['seconds']=round(time.monotonic()-started,3);results.append(result)
  emit({'event':'reply','paths':results})
finally:
 stop.set();listener.close();t.join(3);selector.close()
 emit({'event':'cleanup','ownedThreadStopped':not t.is_alive(),'ownedListenerClosed':listener.fileno()==-1,'persistentFilesCreated':0})
'''
class Agent:
 def __init__(self,n,host,ip,target):
  self.n=n;self.child=None;self.buffer=b'';self.selector=None;self.events=[];owned.append(self)
  command=[sys.executable,'-B','-c',REMOTE] if target is None else ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',target,'python3 -B -c '+shlex.quote(REMOTE)]
  self.child=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
  os.set_blocking(self.child.stdout.fileno(),False)
  self.selector=selectors.DefaultSelector();self.selector.register(self.child.stdout,selectors.EVENT_READ)
  self.child.stdin.write(json.dumps({'host':host,'ip':ip,'challenge':challenge}).encode()+b'\n');self.child.stdin.flush()
  self.ready=self.read(15);assert self.ready['event']=='ready'
 def read(self,seconds):
  deadline=time.monotonic()+seconds
  while time.monotonic()<deadline:
   if b'\n' in self.buffer:
    line,self.buffer=self.buffer.split(b'\n',1);v=json.loads(line);self.events.append(v);return v
   if not self.selector.select(.2):continue
   chunk=os.read(self.child.stdout.fileno(),8192)
   if not chunk:raise RuntimeError('path_agent_closed')
   self.buffer+=chunk;assert len(self.buffer)<=16384
  raise RuntimeError('path_agent_deadline')
 def send(self,value):self.child.stdin.write(json.dumps(value).encode()+b'\n');self.child.stdin.flush()
 def finish(self):
  value={'node':self.n,'cleanupConfirmed':False}
  if self.child is None:return value
  try:self.send({'action':'finish'})
  except (BrokenPipeError,OSError):pass
  self.child.stdin.close()
  try:
   while True:
    answer=self.read(8)
    if answer.get('event')=='cleanup':value=answer;break
  except (OSError,RuntimeError):pass
  finally:
   try:value['processExitCode']=self.child.wait(timeout=8)
   except subprocess.TimeoutExpired:
    self.child.terminate()
    try:value['processExitCode']=self.child.wait(timeout=5)
    except subprocess.TimeoutExpired:self.child.kill();value['processExitCode']=self.child.wait(timeout=3)
   if self.selector:self.selector.close()
   self.child.stdout.close()
  value['node']=self.n;return value
owned=[];agents={};challenge=uuid.uuid4().hex+uuid.uuid4().hex
r={'schemaVersion':1,'scope':'Six directed actual private-Tailscale TCP paths with bounded disposable challenge echo, no application credentials/content','firewallOrRouterChanges':0,'persistentFilesCreated':0,'noiseRpcTested':False,'canonicalWriterPermitted':False,'paths':[]}
try:
 for row in [(1,'dotRonin','100.80.172.12',None),(2,'bazzite','100.87.255.66','Ronin@100.87.255.66'),(3,'192.168.1.11','100.104.166.42','Iyoku@100.104.166.42')]:agents[row[0]]=Agent(*row)
 for n,a in agents.items():
  a.send({'action':'probe','targets':[{'node':m,'address':b.ready['address']} for m,b in agents.items() if m!=n]})
  reply=a.read(8);assert reply['event']=='reply'
  for v in reply['paths']:r['paths'].append(dict(source=n,**v))
 r['status']='PASS' if len(r['paths'])==6 and all(p['status']=='PASS' for p in r['paths']) else 'FAIL'
except BaseException as error:r.update({'status':'FAIL','errorType':type(error).__name__})
finally:
 r['cleanup']=[a.finish() for a in owned]
 if len(r['cleanup'])!=3 or any(not c.get('ownedThreadStopped') or not c.get('ownedListenerClosed') or c.get('processExitCode')!=0 for c in r['cleanup']):r['status']='FAIL'
 r['recordedAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 source=Path(__file__).read_bytes();r['runnerSourceSha256']=hashlib.sha256(source).hexdigest()
 with (B/'private-tcp-allowed-port-contracts.json').open('x') as out:json.dump(r,out,indent=2);out.write('\n')
 with (B/'private-tcp-allowed-port-runner.py.gz').open('xb') as out:out.write(gzip.compress(source,mtime=0))
 assert gzip.decompress((B/'private-tcp-allowed-port-runner.py.gz').read_bytes())==source
 print(json.dumps(r),flush=True)
sys.exit(0 if r['status']=='PASS' else 1)
