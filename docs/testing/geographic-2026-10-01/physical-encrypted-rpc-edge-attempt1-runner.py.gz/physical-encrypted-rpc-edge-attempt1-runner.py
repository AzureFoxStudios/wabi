import base64,datetime,gzip,hashlib,importlib.util,json,os,selectors,shlex,subprocess,sys,time,uuid
from pathlib import Path
REPO=Path('/home/ironin/wabi');BASE=REPO/'docs/testing/geographic-2026-10-01'
spec=importlib.util.spec_from_file_location('physical_control',REPO/'scripts/geographic-acceptance/rpc-probe-controller.py')
ctl=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ctl;spec.loader.exec_module(ctl)
SOURCE_NAMES=('rpc-probe-controller.py','rpc-probe-supervisor.py')
helpers={n:{'body':(REPO/'scripts/geographic-acceptance'/n).read_text(),'sha256':hashlib.sha256((REPO/'scripts/geographic-acceptance'/n).read_bytes()).hexdigest()} for n in SOURCE_NAMES}
accepted=json.loads((BASE/'encrypted-rpc-contracts.json').read_text())
artifact=next(a for a in accepted['artifacts'] if 'encrypted_tcp_contract-' in a['path'])
raw=(REPO/artifact['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==artifact['sha256']
packed=gzip.compress(raw,compresslevel=3,mtime=0);del raw
compressed_artifact=packed
owner=uuid.uuid4().hex+uuid.uuid4().hex
REMOTE=r'''
import base64,gzip,hashlib,importlib.util,io,json,os,platform,selectors,shutil,signal,socket,subprocess,sys,tempfile,threading,time
from pathlib import Path
payload=json.loads(sys.stdin.buffer.readline(65537));assert platform.node()==payload['host']
assert payload['node'] in (1,2,3) and len(payload['owner'])==64
assert payload['artifact']['bytes']<256*1024*1024
assert 0<payload['compressedBytes']<64*1024*1024
compressed=sys.stdin.buffer.read(payload['compressedBytes'])
assert len(compressed)==payload['compressedBytes']
stage=Path(tempfile.mkdtemp(prefix='wgp-',dir='/tmp'));stage.chmod(0o700);original=stage.stat()
root=stage/'n';root.mkdir(mode=0o700);session=None;lease=None;thread=None;reader=None;reserved=None
supervision={};interrupted=False;configured=False;before_kill=None
worker_reserved=None;proxy_listener=None;proxy_thread=None
proxy_stop=threading.Event();proxy_lock=threading.Lock();proxy_blocked=frozenset();proxy_active={};proxy_workers=[]
def interrupt(*_):
 global interrupted
 interrupted=True
for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(sig,interrupt)
def emit(value):print(json.dumps(value,separators=(',',':')),flush=True)
def private_json(path,value):
 body=json.dumps(value,separators=(',',':'),ensure_ascii=True).encode()
 assert len(body)<=16384
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as out:out.write(body);out.flush();os.fsync(out.fileno())
 return hashlib.sha256(body).hexdigest()
def supervise():
 try:supervision.update(session.run(reader,lifetime=110,idle=12,allow_restart=True))
 except BaseException as error:supervision.update({'result':'FAIL','errorType':type(error).__name__})
def inode(name):
 info=(root/name).stat();return [info.st_dev,info.st_ino]
def forward_connection(incoming):
 outgoing=None;source=None
 try:
  incoming.settimeout(2);header=b''
  while len(header)<118:
   part=incoming.recv(118-len(header))
   if not part:return
   header+=part
  assert header[:4]==b'WRC1'
  source=int.from_bytes(header[6:14],'big');target=int.from_bytes(header[14:22],'big')
  assert source in (1,2,3) and source!=payload['node'] and target==payload['node']
  with proxy_lock:
   if source in proxy_blocked or proxy_stop.is_set():return
  outgoing=socket.create_connection(worker_address,timeout=1)
  with proxy_lock:
   if source in proxy_blocked or proxy_stop.is_set():return
   proxy_active[id(incoming)]=(source,incoming,outgoing)
  outgoing.settimeout(1);outgoing.sendall(header)
  incoming.settimeout(1)
  with selectors.DefaultSelector() as readable:
   readable.register(incoming,selectors.EVENT_READ,outgoing);readable.register(outgoing,selectors.EVENT_READ,incoming)
   end=time.monotonic()+5
   while not proxy_stop.is_set() and time.monotonic()<end:
    for key,_ in readable.select(.1):
     chunk=key.fileobj.recv(32768)
     if not chunk:return
     key.data.sendall(chunk)
 except (OSError,AssertionError,ValueError):pass
 finally:
  with proxy_lock:proxy_active.pop(id(incoming),None)
  incoming.close()
  if outgoing is not None:outgoing.close()
def proxy_serve():
 accepted=0;proxy_listener.settimeout(.2)
 while not proxy_stop.is_set() and accepted<256:
  for existing in list(proxy_workers):
   if not existing.is_alive():existing.join();proxy_workers.remove(existing)
  try:incoming,_=proxy_listener.accept()
  except (socket.timeout,OSError):continue
  accepted+=1
  if len(proxy_workers)>=8:incoming.close();continue
  task=threading.Thread(target=forward_connection,args=(incoming,));proxy_workers.append(task);task.start()
def block_peers(peers):
 global proxy_blocked
 assert isinstance(peers,list) and len(peers)<=2 and all(n in (1,2,3) and n!=payload['node'] for n in peers)
 with proxy_lock:
  proxy_blocked=frozenset(peers)
  for source,incoming,outgoing in list(proxy_active.values()):
   if source in proxy_blocked:incoming.close();outgoing.close()
try:
 for name,record in payload['helpers'].items():
  assert name in ('rpc-probe-controller.py','rpc-probe-supervisor.py')
  data=record['body'].encode();assert hashlib.sha256(data).hexdigest()==record['sha256']
  with (stage/name).open('xb') as out:out.write(data)
  (stage/name).chmod(0o600)
 source=importlib.util.spec_from_file_location('agent_control',stage/'rpc-probe-controller.py')
 ctl=importlib.util.module_from_spec(source);sys.modules[source.name]=ctl;source.loader.exec_module(ctl);guard=ctl.guard
 with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:binary=stream.read(payload['artifact']['bytes']+1)
 assert len(binary)==payload['artifact']['bytes'] and hashlib.sha256(binary).hexdigest()==payload['artifact']['sha256']
 executable=root/'probe.bin'
 with executable.open('xb') as out:out.write(binary);out.flush();os.fsync(out.fileno())
 executable.chmod(0o700);del binary,compressed
 private_json(root/'fixture.json',{'schemaVersion':1,'nodeId':payload['node'],'owner':payload['owner']})
 child=subprocess.Popen([str(executable),'--exact','processes::separate_process_identity_bootstrap','--ignored','--nocapture','--test-threads=1'],
  stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
  env={'WABI_RPC_FIXTURE_ROOT':str(root),'WABI_RPC_FIXTURE_OWNER':payload['owner']})
 try:output,_=child.communicate(timeout=10)
 finally:
  if child.poll() is None:child.kill();child.wait(timeout=5)
  if child.stdout:child.stdout.close()
 assert child.returncode==0 and len(output)<=4096
 tagged=[line.split(b'WABI_RPC_NODE_PUBLIC_V1 ',1)[1] for line in output.splitlines() if b'WABI_RPC_NODE_PUBLIC_V1 ' in line]
 assert len(tagged)==1
 public=json.loads(tagged[0]);assert public['nodeId']==payload['node'] and guard.hex64(public['publicKey'])
 reserved=socket.socket(socket.AF_INET,socket.SOCK_STREAM);reserved.bind((payload['ip'],3000 if payload['node']==3 else 0))
 address=payload['ip']+':'+str(reserved.getsockname()[1])
 worker_reserved=socket.socket(socket.AF_INET,socket.SOCK_STREAM);worker_reserved.bind(('127.0.0.1',0))
 worker_address=worker_reserved.getsockname();worker_bind=worker_address[0]+':'+str(worker_address[1])
 emit({'event':'ready','node':payload['node'],'host':platform.node(),'python':platform.python_version(),'publicKey':public['publicKey'],
       'address':address,'workerBind':worker_bind,'artifactSha256':payload['artifact']['sha256'],'artifactBytes':payload['artifact']['bytes']})
 selector=selectors.DefaultSelector();selector.register(sys.stdin.buffer,selectors.EVENT_READ)
 deadline=time.monotonic()+300;commands=0
 while not interrupted and time.monotonic()<deadline and commands<128:
  if lease is not None:lease.keepalive()
  if not selector.select(.1):continue
  line=sys.stdin.buffer.readline(4097)
  if not line:break
  assert len(line)<=4096
  request=ctl.decode(line.strip());commands+=1
  action=request['action']
  try:
   if action=='configure':
    assert not configured
    config=request['config']
    assert config['binding']['nodeId']==payload['node'] and config['owner']==payload['owner']
    assert config['peers'][str(payload['node'])]['publicKey']==public['publicKey'] and config['bindAddress']==worker_bind
    assert config['peers'][str(payload['node'])]['rpcAddress']==address
    (root/'fixture.json').unlink();config_sha=private_json(root/'fixture.json',config)
    session=guard.Session(str(root),payload['owner'],payload['artifact']['sha256'],payload['node'],claim=True)
    reader,writer=os.pipe();os.set_blocking(writer,False);lease=ctl.Lease(writer);os.close(writer)
    client=ctl.Client(str(root),payload['owner'],payload['artifact']['sha256'],config_sha,payload['node'],lease=lease)
    proxy_listener=reserved;reserved=None;proxy_listener.listen(8)
    proxy_thread=threading.Thread(target=proxy_serve);proxy_thread.start()
    worker_reserved.close();worker_reserved=None
    thread=threading.Thread(target=supervise);thread.start();configured=True
    deadline=time.monotonic()+150
    response={'configSha256':config_sha}
   elif action=='control':
    assert configured
    intent=ctl.Intent.from_command(request['command']) if 'command' in request else None
    observation=client.request(request['controlAction'],intent=intent,timeout=request.get('timeout',5))
    response={'request':ctl.decode(observation.request),'reply':observation.value}
   elif action=='kill':
    assert configured and session.child is not None and session.child.poll() is None
    before_kill={'lock':inode('.lock'),'key':inode('recovery.key')}
    child=session.child;child.kill();child.wait(timeout=5)
    response={'knownOwnedChildKilledAndReaped':True}
   elif action=='restart':
    assert configured and before_kill is not None
    lease.restart();response={'restartFrameSent':True}
   elif action=='restart_identity':
    assert configured and before_kill is not None
    response={'originalStoreLockAndPrivateKeyInodesPreserved':before_kill=={'lock':inode('.lock'),'key':inode('recovery.key')}}
   elif action=='partition':
    assert configured
    block_peers(request['blockedPeers']);response={'blockedPeerCount':len(proxy_blocked),'ownedConnectionsOnly':True}
   elif action=='finish':break
   else:raise ValueError('unsupported_action')
   emit({'event':'reply','status':'ok','result':response})
  except ctl.Indeterminate:emit({'event':'reply','status':'indeterminate','originalOperationReceiptRequired':True})
  except (ctl.Refused,OSError,ValueError,KeyError,AssertionError):emit({'event':'reply','status':'refused'})
 selector.close()
except BaseException as error:
 try:emit({'event':'setup_error','errorType':type(error).__name__})
 except BrokenPipeError:pass
finally:
 if reserved is not None:reserved.close()
 if worker_reserved is not None:worker_reserved.close()
 proxy_stop.set()
 if proxy_listener is not None:proxy_listener.close()
 with proxy_lock:
  for source,incoming,outgoing in list(proxy_active.values()):incoming.close();outgoing.close()
 if proxy_thread is not None:proxy_thread.join(3)
 for task in proxy_workers:task.join(3)
 proxy_alive=(proxy_thread is not None and proxy_thread.is_alive()) or any(t.is_alive() for t in proxy_workers)
 if lease is not None:
  try:lease.stop()
  except (OSError,ctl.Refused):pass
  lease.close()
 if thread is not None:thread.join(timeout=18)
 alive=thread is not None and thread.is_alive()
 if session is not None and not alive:session.close()
 if reader is not None and not alive:os.close(reader)
 # Pre-start refusal has no store/worker; only this newly owned private stage.
 if session is None and root.exists():shutil.rmtree(root)
 node_removed=not root.exists()
 if not alive and not proxy_alive and node_removed:
  assert (stage.stat().st_dev,stage.stat().st_ino)==(original.st_dev,original.st_ino)
  shutil.rmtree(stage)
 cleanup={'event':'cleanup','node':payload['node'],'ownedThreadStopped':not alive,'ownedNodeRootRemoved':node_removed,
          'ownedParentStageRemoved':not stage.exists(),'ownedProxyThreadsStopped':not proxy_alive,'ownedProxyListenerClosed':proxy_listener is None or proxy_listener.fileno()==-1,'supervisor':supervision}
 try:emit(cleanup)
 except BrokenPipeError:pass
'''

owned_agents=[]
class Agent:
 def __init__(self,node,site,host,ip,target):
  self.node,self.site=node,site;self.buffer=b'';self.events=[]
  self.child=self.stderr=self.selector=None;self.finished=False
  owned_agents.append(self)
  self.stderr_path=Path('/tmp/wabi-geo-physical-edge-20261001-b418e6-'+str(node)+'.stderr')
  self.stderr=self.stderr_path.open('xb')
  command=[sys.executable,'-B','-c',REMOTE] if target is None else ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',target,'python3 -B -c '+shlex.quote(REMOTE)]
  self.child=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr)
  os.set_blocking(self.child.stdin.fileno(),False)
  os.set_blocking(self.child.stdout.fileno(),False)
  self.selector=selectors.DefaultSelector();self.selector.register(self.child.stdout,selectors.EVENT_READ)
  payload={'node':node,'site':site,'host':host,'ip':ip,'owner':owner,'artifact':artifact,'compressedBytes':len(compressed_artifact),'helpers':helpers}
  self.write(json.dumps(payload,separators=(',',':')).encode()+b'\n',5)
  self.write(compressed_artifact,90)
  self.ready=self.read(45);assert self.ready['event']=='ready' and self.ready['node']==node and self.ready['host']==host
 def write(self,body,seconds):
  end=time.monotonic()+seconds;offset=0
  with selectors.DefaultSelector() as writable:
   writable.register(self.child.stdin,selectors.EVENT_WRITE)
   while offset<len(body):
    if self.child.poll() is not None:raise RuntimeError('agent_exited_during_bounded_write')
    remaining=end-time.monotonic()
    if remaining<=0:raise RuntimeError('agent_write_deadline')
    if not writable.select(min(.25,remaining)):continue
    try:offset+=os.write(self.child.stdin.fileno(),body[offset:offset+65536])
    except BlockingIOError:continue
 def read(self,seconds):
  end=time.monotonic()+seconds
  while time.monotonic()<end:
   if b'\n' in self.buffer:
    line,self.buffer=self.buffer.split(b'\n',1);value=json.loads(line);self.events.append(value);return value
   if self.selector.select(min(.25,max(0,end-time.monotonic()))):
    part=os.read(self.child.stdout.fileno(),8192)
    if not part:raise RuntimeError('agent_closed_before_receipt')
    self.buffer+=part
    assert len(self.buffer)<65536
  raise RuntimeError('agent_reply_deadline')
 def call(self,action,**fields):
  body=ctl.encoded(dict(action=action,**fields));assert len(body)<=4096
  self.write(body+b'\n',5)
  value=self.read(12);assert value['event']=='reply'
  return value
 def control(self,action,intent=None,timeout=5):
  fields={'controlAction':action,'timeout':timeout}
  if intent is not None:fields['command']=intent.command
  return self.call('control',**fields)
 def finish(self):
  assert not self.finished;self.finished=True
  value={'node':self.node,'cleanupConfirmed':False}
  if self.child is None:
   if self.stderr is not None:self.stderr.close()
   return value
  if self.child.poll() is None:
   try:self.write(b'{"action":"finish"}\n',2)
   except (BrokenPipeError,OSError,RuntimeError):pass
  if self.child.stdin:self.child.stdin.close()
  try:
   end=time.monotonic()+24
   while time.monotonic()<end:
    received=self.read(max(.1,end-time.monotonic()))
    if received.get('event')=='cleanup':value=received;break
  except (OSError,RuntimeError,AssertionError,json.JSONDecodeError) as error:
   value['cleanupReadErrorType']=type(error).__name__
  finally:
   try:value['processExitCode']=self.child.wait(timeout=10)
   except subprocess.TimeoutExpired:
    # This is our known local Python/SSH child, never an arbitrary remote PID.
    self.child.terminate()
    try:value['processExitCode']=self.child.wait(timeout=20)
    except subprocess.TimeoutExpired:
     self.child.kill();value['processExitCode']=self.child.wait(timeout=5)
    value['localTransportTerminationRequired']=True
   if self.selector is not None:self.selector.close()
   if self.child.stdout:self.child.stdout.close()
   if self.stderr is not None:self.stderr.close()
  value['knownLocalTransportReaped']=True
  return value

agents={};outcomes=[];intents=[];cleanup=[]
def observation(node,answer):
 assert answer['status']=='ok'
 value=answer['result'];ctl.validate_reply(value['reply'],node,(1,2,3))
 return ctl.Observation(ctl.encoded(value['request']),ctl.encoded(value['reply']))
def leader(ids,seconds=25):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  for node in ids:
   answer=agents[node].control('status',timeout=2)
   if answer['status']=='ok' and observation(node,answer).value['isLeader']:return node
  time.sleep(.1)
 raise RuntimeError('physical_leader_deadline')
def receipt_set(intent,ids,seconds=18):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  try:
   values=[observation(n,agents[n].control('receipt',intent,timeout=2)) for n in ids]
   controls=[ctl.accepted_receipt(v,intent) for v in values]
   assert all(v==controls[0] for v in controls)
   if len(ids)==3:ctl.convergence(values,intent)
   return values
  except (AssertionError,ctl.Refused):time.sleep(.1)
 raise RuntimeError('physical_exact_receipt_deadline')
def submit(ids,epoch):
 node=leader(ids)
 intent=ctl.Intent.from_command({'operationId':format(epoch+1,'032x'),'partitionId':'room:fixture','expectedEpoch':epoch,
    'proposedWriter':node,'checkpointInventorySha256':'ab'*32})
 started=time.monotonic();answer=agents[node].control('propose',intent,timeout=5)
 assert answer['status'] in ('ok','indeterminate')
 values=receipt_set(intent,ids)
 intents.append(intent)
 outcomes.append({'operation':epoch+1,'acknowledgingNode':node,'availableVoters':list(ids),'originalCommandSha256':intent.sha256,
   'exactReceipt':ctl.accepted_receipt(values[0],intent),'endToEndSeconds':round(time.monotonic()-started,3),'proposalReply':answer['status']})
 return intent

result={'schemaVersion':1,'scope':'Disposable three-physical-host encrypted recovery metadata minority partition and purged snapshot catch-up, with owned opaque TCP proxies on private Tailscale IPs',
 'artifact':artifact,'artifactCompressedTransferBytesPerRemote':23599998,'physicalSitesIndependentlyCertified':False,
 'placementEvidence':'Earlier three-exit observation and operator site report; no public-address check repeated',
 'iyokuUsesExistingAllowedUnusedPrivatePort3000':True,'opaqueOwnedTcpProxies':True,'globalNetworkInterfacesChanged':0,
 'canonicalWriterPermitted':False,'automaticWabiRecoveryTested':False,'wabiAuthorityLaunched':False,'publicRouterOrFirewallChanges':0}
try:
 for row in [(1,'dotRonin','dotRonin','100.80.172.12',None),(2,'Ronin','bazzite','100.87.255.66','Ronin@100.87.255.66'),
             (3,'Iyoku','192.168.1.11','100.104.166.42','Iyoku@100.104.166.42')]:
  result['phase']='node_setup_'+str(row[0])
  agents[row[0]]=Agent(*row)
 assert len({a.ready['publicKey'] for a in agents.values()})==3
 community=hashlib.sha256(uuid.uuid4().bytes).hexdigest()
 peers={str(n):{'protocol':1,'communityId':community,'siteId':a.site,'publicKey':a.ready['publicKey'],'rpcAddress':a.ready['address']} for n,a in agents.items()}
 for n,a in agents.items():
  result['phase']='node_configure_'+str(n)
  config={'binding':{'communityId':community,'partitionId':'room:fixture','nodeId':n},'peers':peers,'bindAddress':a.ready['workerBind'],
    'owner':owner,'raftTiming':{'heartbeatMs':1000,'electionMinMs':4000,'electionMaxMs':7000,'snapshotTimeoutMs':10000}}
  assert a.call('configure',config=config)['status']=='ok'
 end=time.monotonic()+12
 for n,a in agents.items():
  while time.monotonic()<end:
   answer=a.control('status',timeout=1)
   if answer['status']=='ok':observation(n,answer);break
  else:raise RuntimeError('physical_worker_startup_deadline')
 assert agents[1].control('initialize',timeout=5)['status']=='ok'
 result['phase']='initial_majority_write'
 submit((1,2,3),0)
 result['phase']='physical_minority_cut'
 isolated=leader((1,2,3));majority=tuple(n for n in (1,2,3) if n!=isolated)
 for n,a in agents.items():assert a.call('partition',blockedPeers=list(majority) if n==isolated else [isolated])['status']=='ok'
 minority=ctl.Intent.from_command({'operationId':format(99,'032x'),'partitionId':'room:fixture','expectedEpoch':1,'proposedWriter':isolated,'checkpointInventorySha256':'ab'*32})
 answer=agents[isolated].control('propose',minority,timeout=5)
 assert answer['status'] in ('ok','indeterminate')
 if answer['status']=='ok':
  reply=observation(isolated,answer).value;assert reply['result'] in ('refused','indeterminate') and reply['control'] is None
 accepted=submit(majority,1)
 for n in majority:assert observation(n,agents[n].control('receipt',minority)).value['control'] is None
 for a in agents.values():assert a.call('partition',blockedPeers=[])['status']=='ok'
 receipt_set(accepted,(1,2,3))
 for n in (1,2,3):
  value=observation(n,agents[n].control('receipt',minority)).value
  assert value['control'] is None and value['minorityOperationPresent'] is False
 result['physicalMinorityPartition']={'isolatedFormerLeader':isolated,'availableMajority':list(majority),'canonicalAckOnMinority':False,'majorityOperationAccepted':True,'uncommittedMinorityIntentAbsentAfterHeal':True,'cutScope':'Only owned opaque proxy connections/listeners; no firewall/interface rules'}
 result['phase']='physical_snapshot_missing_follower'
 current=leader((1,2,3));missing=next(n for n in (1,2,3) if n!=current)
 old_applied=observation(missing,agents[missing].control('status')).value['durableAppliedIndex']
 assert agents[missing].call('kill')['result']['knownOwnedChildKilledAndReaped']
 majority=tuple(n for n in (1,2,3) if n!=missing)
 for _ in range(30):last=submit(majority,len(intents))
 end=time.monotonic()+10;purged=None
 while time.monotonic()<end:
  state=observation(current,agents[current].control('status')).value
  purged=state['observedPurgedIndex']
  if purged is not None and purged>max(10,old_applied):break
  time.sleep(.1)
 else:raise RuntimeError('physical_purge_not_observed')
 assert agents[missing].call('restart')['status']=='ok'
 values=receipt_set(last,(1,2,3));returned=next(v.value for v in values if v.value['nodeId']==missing)
 assert returned['observedSnapshotIndex'] is not None and returned['observedSnapshotIndex']>max(10,old_applied)
 assert returned['operations']==32 and returned['epoch']==32
 assert agents[missing].call('restart_identity')['result']['originalStoreLockAndPrivateKeyInodesPreserved']
 snapshot_index=returned['observedSnapshotIndex']
 assert agents[missing].call('kill')['result']['knownOwnedChildKilledAndReaped']
 assert agents[missing].call('restart')['status']=='ok'
 final=receipt_set(last,(1,2,3))
 receipt_set(intents[0],(1,2,3));receipt_set(intents[1],(1,2,3))
 assert agents[missing].call('restart_identity')['result']['originalStoreLockAndPrivateKeyInodesPreserved']
 assert all(v.value['operations']==32 and v.value['epoch']==32 and not v.value['minorityOperationPresent'] for v in final)
 result['physicalPurgedSnapshotCatchup']={'missingNode':missing,'missingAppliedIndexBeforeKill':old_applied,'majorityPurgedIndex':purged,'returnedSnapshotIndex':snapshot_index,'majorityOperationsWhileMissing':30,'exactFullStateConvergence':True,'operationCount':32,'secondRestartPreservesExactState':True,'initialAndPostPartitionReceiptsReadBack':True,'originalKeyAndStoreLockInodesPreserved':True}
 result.update({'status':'PASS','nodes':[{'node':n,'site':a.site,'host':a.ready['host'],'python':a.ready['python'],'artifactSha256':a.ready['artifactSha256']} for n,a in agents.items()],
  'threeIndependentDisposableNodeKeys':True,'initialAllThreeExactReceiptConvergence':True,
  'operations':outcomes,'noiseRaftPhysicalControlTested':True,'physicalMinorityPartitionTested':True,'physicalSnapshotAfterPurgeTested':True})
except BaseException as error:
 result.update({'status':'FAIL','errorType':type(error).__name__,'completedOperations':outcomes})
 if isinstance(error,RuntimeError) and str(error).replace('_','').isalnum():result['boundedFailureReason']=str(error)
finally:
 for a in owned_agents:
  try:cleanup.append(a.finish())
  except BaseException as error:cleanup.append({'node':a.node,'errorType':type(error).__name__,'cleanupConfirmed':False})
 result['cleanup']=cleanup
 result['controlObservations']={str(a.node):[v for v in a.events if v.get('event')=='reply'] for a in owned_agents}
 if len(cleanup)!=3 or any(not c.get('ownedNodeRootRemoved') or not c.get('ownedParentStageRemoved') or not c.get('ownedThreadStopped') or not c.get('ownedProxyThreadsStopped') or not c.get('ownedProxyListenerClosed') or c.get('processExitCode')!=0 for c in cleanup):result['status']='FAIL'
 result['recordedAtUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 result['helperSourceDigests']={n:v['sha256'] for n,v in helpers.items()}
 source=Path(__file__).read_bytes();result['runnerSourceSha256']=hashlib.sha256(source).hexdigest()
 with (BASE/'physical-encrypted-rpc-edge-contracts.json').open('x') as out:json.dump(result,out,indent=2);out.write('\n')
 with (BASE/'physical-encrypted-rpc-edge-runner.py.gz').open('xb') as out:out.write(gzip.compress(source,mtime=0))
 assert gzip.decompress((BASE/'physical-encrypted-rpc-edge-runner.py.gz').read_bytes())==source
 print(json.dumps({'status':result['status'],'errorType':result.get('errorType'),'operations':len(outcomes),'cleanup':cleanup}),flush=True)
sys.exit(0 if result['status']=='PASS' else 1)
