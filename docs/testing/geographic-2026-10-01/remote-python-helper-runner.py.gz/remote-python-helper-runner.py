import base64
import concurrent.futures
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys
import uuid

ROOT = Path('/home/ironin/wabi')
FILES = {
    'rpc-probe-supervisor.py': '713cea7e45d5cd73abb2e7015e9dff02595bbe0bd7478fcffb939a5ca3b671b2',
    'rpc-probe-supervisor.test.py': '52578b172841e73cbd25f7af3659e1205b2a6553a71c03c7dd18659d4a5dabab',
    'rpc-probe-controller.py': 'cbb16bed861a55a6d978a006065e4cd6e9e57410f4ed669c5acf3f9db791eb9e',
    'rpc-probe-controller.test.py': 'dfc4ea8fc0420f9815b9d56280f3ee5d455f3a49029354675c9f96ea39b58ab0',
}
REMOTE = r'''
import base64,datetime,gzip,hashlib,json,os,platform,re,shutil,signal,subprocess,sys,tempfile,time
from pathlib import Path
payload=json.loads(sys.stdin.buffer.read(200001))
assert set(payload)=={'site','expectedHost','nonce','files'}
assert platform.node()==payload['expectedHost']
assert set(payload['files'])=={'rpc-probe-supervisor.py','rpc-probe-supervisor.test.py','rpc-probe-controller.py','rpc-probe-controller.test.py'}
assert re.fullmatch('[0-9a-f]{8}',payload['nonce'])
assert sys.platform=='linux'
stage=Path(tempfile.mkdtemp(prefix='wgr-'+payload['nonce']+'-',dir='/tmp'))
stage.chmod(0o700)
initial=stage.stat()
owner=stage/'.owner'
owner.write_text(payload['nonce']);owner.chmod(0o600)
interrupted=False
def on_signal(*_):
    global interrupted
    interrupted=True
for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT): signal.signal(sig,on_signal)
def live_group(group):
    found=[]
    for item in Path('/proc').iterdir():
        if not item.name.isdigit(): continue
        try:
            text=(item/'stat').read_text()
            fields=text[text.rfind(')')+2:].split()
            if int(fields[2])==group and fields[0]!='Z': found.append(int(item.name))
        except (FileNotFoundError,ProcessLookupError,PermissionError): pass
    return found
results=[];cleanup={'ownedRootRemoved':False,'ownedLiveProcessGroupsRemaining':[], 'bytecodeCachesRemaining':[]}
overall_error=None
try:
    for name,record in payload['files'].items():
        body=record['body'].encode()
        assert hashlib.sha256(body).hexdigest()==record['sha256']
        path=stage/name
        with path.open('xb') as out: out.write(body)
        path.chmod(0o600)
    temp=stage/'t';temp.mkdir(mode=0o700)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(temp))
    for name,expected in [('rpc-probe-supervisor.test.py',33),('rpc-probe-controller.test.py',25)]:
        log=stage/(name+'.log')
        started=time.monotonic();reason=None;child=None
        try:
            with log.open('xb') as output:
                child=subprocess.Popen([sys.executable,'-W','error::ResourceWarning',str(stage/name),'-v'],
                    cwd=stage,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
                # Observe terminal state without reaping: the reserved group-leader PID
                # keeps cleanup signals scoped to this exact newly owned session.
                while os.waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT) is None:
                    if interrupted or time.monotonic()-started>60 or log.stat().st_size>1024*1024:
                        reason='interrupted' if interrupted else 'timeout_or_output_budget'
                        break
                    time.sleep(.05)
                remaining=live_group(child.pid)
                if remaining:
                    os.killpg(child.pid,signal.SIGKILL)
                deadline=time.monotonic()+5
                while live_group(child.pid) and time.monotonic()<deadline: time.sleep(.05)
                cleanup['ownedLiveProcessGroupsRemaining'].extend(live_group(child.pid))
                code=child.wait(timeout=5)
        finally:
            if child is not None and child.returncode is None:
                os.killpg(child.pid,signal.SIGKILL)
                child.wait(timeout=5)
        raw=log.read_bytes()
        match=re.search(rb'Ran (\d+) tests? in ',raw)
        skipped=bool(re.search(rb'skipped|skip=',raw,re.I))
        status='PASS' if code==0 and reason is None and match and int(match[1])==expected and not skipped else 'FAIL'
        results.append({'suite':name,'status':status,'exitCode':code,'testsRun':int(match[1]) if match else None,
            'expectedTests':expected,'skippedObserved':skipped,'elapsedSeconds':round(time.monotonic()-started,3),
            'terminationReason':reason,'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),
            'logGzipBase64':base64.b64encode(gzip.compress(raw,mtime=0)).decode()})
        if interrupted: break
except Exception as error:
    overall_error=type(error).__name__
finally:
    cleanup['bytecodeCachesRemaining']=[str(p.relative_to(stage)) for p in stage.rglob('__pycache__')]
    cleanup['testRootsRemainingBeforeStageRemoval']=[p.name for p in (stage/'t').iterdir()] if (stage/'t').exists() else []
    final=stage.lstat()
    if (final.st_dev,final.st_ino)==(initial.st_dev,initial.st_ino) and owner.read_text()==payload['nonce'] and not cleanup['ownedLiveProcessGroupsRemaining']:
        shutil.rmtree(stage)
    cleanup['ownedRootRemoved']=not stage.exists()
receipt={'schemaVersion':1,'site':payload['site'],'host':platform.node(),'python':platform.python_version(),
    'architecture':platform.machine(),'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceDigests':{n:r['sha256'] for n,r in payload['files'].items()},'results':results,'cleanup':cleanup,'errorType':overall_error,
    'scope':'Synthetic Linux supervisor/controller suites on remote hosts; no Rust, Noise, Raft, keys or TCP',
    'rustNoiseRaftWabiRecoveryTested':False,'canonicalWriterPermitted':False}
receipt['status']='PASS' if len(results)==2 and all(r['status']=='PASS' for r in results) and cleanup['ownedRootRemoved'] and not cleanup['ownedLiveProcessGroupsRemaining'] and overall_error is None else 'FAIL'
print(json.dumps(receipt),flush=True)
sys.exit(0 if receipt['status']=='PASS' else 1)
'''

sources = {}
for name, sha in FILES.items():
    raw=(ROOT/'scripts/geographic-acceptance'/name).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=sha: raise RuntimeError('Released source changed')
    sources[name]={'sha256':sha,'body':raw.decode()}

def run(site,target,host):
    payload={'site':site,'expectedHost':host,'nonce':uuid.uuid4().hex[:8],'files':sources}
    result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',target,
                           'python3 -B -c '+shlex.quote(REMOTE)],input=json.dumps(payload).encode(),
                          stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=165)
    if not result.stdout: raise RuntimeError(site+' returned no receipt; SSH exit '+str(result.returncode))
    receipt=json.loads(result.stdout)
    receipt['sshExitCode']=result.returncode
    receipt['sshStderrBytes']=len(result.stderr)
    for evidence in receipt['results']:
        zipped=base64.b64decode(evidence.pop('logGzipBase64'),validate=True)
        raw=gzip.decompress(zipped)
        assert len(raw)==evidence['rawBytes'] and hashlib.sha256(raw).hexdigest()==evidence['rawSha256']
        path=ROOT/'docs/testing/geographic-2026-10-01'/('remote-python-'+site.lower()+'-'+evidence['suite']+'.log.gz')
        with path.open('xb') as output: output.write(zipped)
        assert gzip.decompress(path.read_bytes())==raw
        evidence['logPath']=str(path.relative_to(ROOT))
    return receipt

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
    futures=[executor.submit(run,*host) for host in [('Ronin','Ronin@100.87.255.66','bazzite'),('Iyoku','Iyoku@100.104.166.42','192.168.1.11')]]
    receipts=[]
    for future in futures:
        try: receipts.append(future.result())
        except Exception as error: receipts.append({'status':'FAIL','localErrorType':type(error).__name__,'message':str(error)[:200]})

receipt={'schemaVersion':1,'recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'executionComputer':'dotRonin','checkout':str(ROOT),'scope':'Released synthetic Python helper remote runtime compatibility',
    'runnerSourceSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'remoteRunnerSourceSha256':hashlib.sha256(REMOTE.encode()).hexdigest(),'nodes':receipts,
    'noSharedBuildOrSourceMutation':True,'newNodeKeys':0,'tcpListeners':0,'wabiServicesLaunched':0,
    'noiseRaftRustCodecPhysicalWabiRecoveryTested':False,'status':'PASS' if all(r['status']=='PASS' for r in receipts) else 'FAIL'}
path=ROOT/'docs/testing/geographic-2026-10-01/remote-python-helper-contracts.json'
with path.open('x') as output: json.dump(receipt,output,indent=2);output.write('\n')
runner=Path(__file__).read_bytes()
archive=path.with_name('remote-python-helper-runner.py.gz')
with archive.open('xb') as output: output.write(gzip.compress(runner,mtime=0))
assert gzip.decompress(archive.read_bytes())==runner
print(json.dumps({'status':receipt['status'],'nodes':[{k:r.get(k) for k in ('site','host','python','status','sshExitCode','cleanup')} for r in receipts],'receipt':str(path)}))
sys.exit(0 if receipt['status']=='PASS' else 1)
